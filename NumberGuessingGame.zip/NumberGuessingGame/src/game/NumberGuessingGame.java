package game;

import java.util.Random;
import java.util.Scanner;

public class NumberGuessingGame {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        
        int totalScore = 0;
        int rounds = 0;
        boolean playAgain = true;
        
        System.out.println("Welcome to the Number Guessing Game!");

        while (playAgain) {
            int numberToGuess = random.nextInt(100) + 1;
            int maxAttempts = 10;
            int attempts = 0;
            boolean guessedCorrectly = false;

            System.out.println("\nI have generated a number between 1 and 100.");
            System.out.println("You have " + maxAttempts + " attempts to guess it.");

            while (attempts < maxAttempts && !guessedCorrectly) {
                System.out.print("Attempt " + (attempts + 1) + ": Enter your guess: ");
                int userGuess = scanner.nextInt();
                attempts++;

                if (userGuess < numberToGuess) {
                    System.out.println("Too low!");
                } else if (userGuess > numberToGuess) {
                    System.out.println("Too high!");
                } else {
                    System.out.println("Correct! You guessed the number.");
                    totalScore += (maxAttempts - attempts + 1);
                    guessedCorrectly = true;
                }
            }

            if (!guessedCorrectly) {
            	System.out.println("Your total score after " + rounds + " rounds is " + totalScore + ".");
            }

            rounds++;
            System.out.println("Your total score after " + rounds + " rounds is " + totalScore + ".");
            
            System.out.print("Do you want to play another round? (yes/no): ");
            String playAgain1 = scanner.next();
            if (!playAgain1.equals("yes")) {
                break;
            }
        }
       

        System.out.println("\nThank you for playing the Number Guessing Game!");
        System.out.println("Your final score is " + totalScore + " after " + rounds + " rounds.");
        
        scanner.close();
    }
}
