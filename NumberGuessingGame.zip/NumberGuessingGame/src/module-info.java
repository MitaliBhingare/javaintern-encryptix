/**
 * 
 */
/**
 * 
 */
module NumberGuessingGame {
}